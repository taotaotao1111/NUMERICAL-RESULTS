function varargout = traffic_gui(varargin)
% TRAFFIC_GUI MATLAB code for traffic_gui.fig
% TRAFFIC_GUI, by itself, creates a new TRAFFIC_GUI or raises the existing
% singleton*.
%
% H = TRAFFIC_GUI returns the handle to a new TRAFFIC_GUI or the handle to
% the existing singleton*.
%
% TRAFFIC_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
% function named CALLBACK in TRAFFIC_GUI.M with the given input arguments.
%
% TRAFFIC_GUI('Property','Value',...) creates a new TRAFFIC_GUI or raises the
% existing singleton*.  Starting from the left, property value pairs are
% applied to the GUI before traffic_gui_OpeningFcn gets called.  An
%unrecognized property name or invalid value makes property application
%stop.  All inputs are passed to traffic_gui_OpeningFcn via varargin.
%
% *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
% instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES
 
% Edit the above text to modify the response to help traffic_gui
 
% Last Modified by GUIDE v2.5 14-Mar-2023 08:54:05
 
% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @traffic_gui_OpeningFcn, ...
                   'gui_OutputFcn',  @traffic_gui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end
 
if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT
 
 
% --- Executes just before traffic_gui is made visible.
function traffic_gui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to traffic_gui (see VARARGIN)
 
% Choose default command line output for traffic_gui
handles.output = hObject;
 
% Update handles structure
guidata(hObject, handles);
 
% UIWAIT makes traffic_gui wait for user response (see UIRESUME)
% uiwait(handles.figure1);
 
 
% --- Outputs from this function are returned to the command line.
function varargout = traffic_gui_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
 
% Get default command line output from handles structure
varargout{1} = handles.output;
 
 
% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global net;
t=5;
for i=1:t
I=imread(['m',num2str(i),'.jpg']);
TrM=rgb2gray(I); 
  
Trlevel=graythresh(TrM);  
TrBW=im2bw(TrM,Trlevel);   
R=~imresize(TrBW,[32,32]);
 
P(:,i)=reshape(R,1024,1);    %�ߴ�任ת��Ϊ1024*1������
end   %forѭ������
T=(1:5);
 
net=newff(P,T,[1024,500,100,50,1],{'logsig','logsig','tansig'},'trainrp');
net.inputWeights{1,1}.initFcn ='randnr';   %Ȩֵ��ʼ��
net.layerWeights{2,1}.initFcn ='randnr';  %��ֵ��ʼ��
net.trainparam.epochs=10000;   %����������
net.trainparam.goal=0.0005;   %�������
net.trainparam.show=100;   %50�����ں���ʾһ���������ߵı仯
net.divideFcn = '';
net=init(net);
load KK;
P=[P,KK];T=[T,(1:t)];
[net,tr]=train(net,P,T);
save net.mat net;
 
 
 
 
% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
load net.mat;
 
 
% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global out_final;
[filename,pathname]=uigetfile({'*.*';'*.bmp';'*.jpg';'*.tif';'*.jpg'},'ѡ��ͼ��');
if isequal(filename,0)||isequal(pathname,0)
  errordlg('����û��ѡȡͼƬ����','��ܰ��ʾ');%���û�����룬�򴴽�����Ի��� 
  return;
else
    image=[pathname,filename];%�ϳ�·��+�ļ���
    I=imread(image);%��ȡͼ��
end
I=imresize(I,[640,480]);
 
[m,n]=size(I);
Hsv=rgb2hsv(I);   %��ͼ����RGB��ɫ�ռ�ת��ΪHSV��ɫ�ռ�
 
I1=Hsv(:,:,1);%I1=histeq(I1);    
 
I2=Hsv(:,:,2);%I2=histeq(I2);      
 
I3=Hsv(:,:,3);    
 
BW1=roicolor(I1,0,0.3); 
BW2=roicolor(I2,0.69,1);
BW=BW1&BW2;
 
 se=strel('square',3);
BW=imerode(BW,se);%����ֵͼ��ʴ��
 
se=strel('disk',10); %����һ��ָ���뾶10��ƽ��Բ���εĽṹԪ��
BW1=imclose(BW,se);%��ͼ���ð�ɫ��
SE=ones(10);
PZ=imdilate(BW1,SE);%����ֵͼ�����ͣ�
 
TC=bwfill(PZ,'holes');
 
LK=bwareaopen(TC,1500);  
 
 
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%ʶ��corr2()
[B,L] = bwboundaries(LK,'noholes');%B�������ʾ�෴��y,x��
len=length(B);
temp_mean=zeros(len,2);
temp_std=zeros(len,2);
temp_min=zeros(len,2);
temp_max=zeros(len,2);
for i=1:len
    temp_mean(i,:)=mean(B{i},1);
    temp_std(i,:)=std(B{i});
    temp_min(i,:)=min(B{i});
    temp_max(i,:)=max(B{i});    
end
out=imcrop(I,[fliplr(temp_min),fliplr(temp_max-temp_min)]); 
 
 out_final=imresize(out,[32 32]);
 
axes(handles.axes1);
imshow(I);
axes(handles.axes2);
imshow(out_final);
 
 
% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global out_final;
global net;
X= out_final;
TeM=rgb2gray(X);
TeM=histeq(TeM);
Televel=graythresh(TeM);   %�ҵ��Ҷ�ͼ��M������Ӧ��ֵ�ָ����ֵ
TeBW=im2bw(TeM,Televel);     %ת������ֵͼ�񣬻Ҷ�ֵ>M,��Ϊ1������Ϊ0
J=~imresize(TeBW,[32,32]); 
 
K=reshape(J,1024,1);
save K.mat K;
T0=sim(net,K);
disp(T0);
T1=round(T0);   %����������������ж�Ϊ����ʵ������о������ֵ�Ľڵ��Ӧ�����
 
str=imread(['m',num2str(T1),'.jpg']);
axes(handles.axes3);
imshow(str);
switch T1
    case 1
        set(handles.text4,'string','ǰ��T�ͽ���·��');
        [au,Fs] = audioread('1.wav');player = audioplayer(au,Fs);play(player);
    case 2
        set(handles.text4,'string','ǰ���Ҳ�·���խ');
        [au,Fs] = audioread('2.wav');player = audioplayer(au,Fs);play(player);
    case 3
        set(handles.text4,'string','ǰ��ע����');
        [au,Fs] = audioread('3.wav');player = audioplayer(au,Fs);play(player);
    case 4
        set(handles.text4,'string','ǰ��·�治ƽ');
        [au,Fs] = audioread('4.wav');player = audioplayer(au,Fs);play(player);
    case 5
        set(handles.text4,'string','ǰ������ת��');
        [au,Fs] = audioread('5.wav');player = audioplayer(au,Fs);play(player);
end
pause(3);